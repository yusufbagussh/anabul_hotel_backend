package entity

type Cage struct {
	IDCage             uint64 `gorm:"primary_key;autoIncrement" json:"id_cage"`
	Name               string `gorm:"type:varchar(100);not null" json:"name"`
	CageCategoryTypeID uint64 `gorm:"not null" json:"-"`
	Status             string `gorm:"not null" json:"status"'`
	Base
	CageCategoryType CageCategoryType `gorm:"foreignkey:CageCategoryTypeID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"category-type"`
}
