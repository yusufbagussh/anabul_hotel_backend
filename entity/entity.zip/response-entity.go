package entity

type Response struct {
	IDResponse uint64 `gorm:"primary_key;autoIncrement" json:"id_response"`
	RateID     uint64 `gorm:"not null" json:"rate_id"`
	Comment    string `gorm:"default:null" json:"comment"`
	Base
	Rate Rate `gorm:"foreignKey:RateID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"rate"`
}
