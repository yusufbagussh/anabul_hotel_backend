package entity

type ReservationDetail struct {
	IDReservationDetail uint64 `gorm:"primary_key;autoIncrement" json:"id_reservation_detail"`
	Name                string `gorm:"type:varchar(100);not null" json:"name"`
	ReservationID       uint64 `gorm:"not null" json:"reservation_id"`
	PetID               uint64 `gorm:"not null" json:"-"`
	CageID              uint64 `gorm:"default:null" json:"-"`
	ProductID           uint64 `gorm:"default:null" json:"-"`
	Base
	Reservation Reservation `gorm:"foreignkey:ReservationID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"reservation"`
	Pet         Pet         `gorm:"foreignkey:PetID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"pet"`
	Cage        Cage        `gorm:"foreignkey:CageID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"cage"`
	Product     Product     `gorm:"foreignkey:ProductID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"product"`
}
