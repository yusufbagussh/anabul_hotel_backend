package entity

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
	"time"
)

type Province struct {
	IDProvince string `gorm:"type:varchar(36);primaryKey;not null" json:"id_province"`
	Name       string `gorm:"type:varchar(100)" json:"name"`
	CreatedAt  time.Time
	UpdatedAt  time.Time
	DeletedAt  gorm.DeletedAt
}

func (p *Province) BeforeCreate(tx *gorm.DB) (err error) {
	p.IDProvince = uuid.NewString()
	return
}
