package entity

type Inventory struct {
	IDInventory         uint64 `gorm:"primary_key;autoIncrement" json:"id_inventory"`
	Name                string `gorm:"type:varchar(100)" json:"name"`
	ReservationDetailID uint64 `gorm:"default:null" json:"-"`
	Base
	ReservationDetail ReservationDetail `gorm:"foreignkey:ReservationDetailID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"reservation_detail"`
}
