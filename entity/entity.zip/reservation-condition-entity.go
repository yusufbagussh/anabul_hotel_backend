package entity

type ReservationCondition struct {
	IDReservationCondition uint64 `gorm:"primary_key;autoIncrement" json:"id_reservation_condition"`
	FeedStatus             string `gorm:"default:null" json:"feed_status"`
	PlayStatus             string `gorm:"default:null" json:"play_status"`
	ReservationDetailID    uint64 `gorm:"default:null" json:"-"`
	CreatedBy              uint64 `gorm:"references:UserID;not null" json:"created_by"`
	UpdatedBy              uint64 `gorm:"references:UserID;not null" json:"updated_by"`
	Base
	ReservationDetail ReservationDetail `gorm:"foreignkey:ReservationDetailID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"reservation_detail"`
	CreatedUser       User              `gorm:"foreignKey:CreatedBy;constraint:onUpdate:CASCADE;onDelete:CASCADE" json:"created_user"`
	UpdatedUser       User              `gorm:"foreignKey:UpdatedBy;constraint:onUpdate:CASCADE;onDelete:CASCADE" json:"updated_user"`
}
