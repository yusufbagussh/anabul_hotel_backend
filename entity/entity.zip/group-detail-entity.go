package entity

type GroupDetail struct {
	IDCategory uint64  `gorm:"primary_key;autoIncrement" json:"id_category"`
	GroupID    uint64  `gorm:"not null" json:"-"`
	SpeciesID  uint64  `gorm:"not null" json:"-"`
	MinWeight  float64 `gorm:"not null" json:"min_weight"`
	MaxWeight  float64 `gorm:"not null" json:"max_weight"`
	Base
	Group   Group   `gorm:"foreignkey:GroupID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"group"`
	Species Species `gorm:"foreignkey:SpeciesID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"species"`
}
