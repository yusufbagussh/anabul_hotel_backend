package entity

import (
	"github.com/google/uuid"
	"time"
)

type Reservation struct {
	IDReservation     uint64    `gorm:"primary_key;autoIncrement" json:"id_reservation"`
	Name              string    `gorm:"type:varchar(100);not null" json:"name"`
	HotelID           uuid.UUID `gorm:"default:null" json:"hotel_id"`
	UserID            uuid.UUID `gorm:"default:null" json:"user_id"`
	StartDate         time.Time
	EndDate           time.Time
	TotalCost         float64 `gorm:"not null" json:"total_cost"`
	DPCost            float64 `gorm:"default:null" json:"dp_cost"`
	PaymentStatus     string  `gorm:"default:'Unpaid'" sql:"type:ENUM('Paid', 'Pending', 'DP', 'Unpaid')" json:"payment_status"`
	CheckInStatus     string  `gorm:"default:'Out'" sql:"type:ENUM('In', 'Out')" json:"check_in_status"`
	ReservationStatus string  `gorm:"default:'Reject'" sql:"type:ENUM('Reject', 'Accept', 'Complete')" json:"reservation_status"`
	CreatedBy         uint64  `gorm:"references:UserID;not null" json:"created_by"`
	UpdatedBy         uint64  `gorm:"references:UserID;not null" json:"updated_by"`
	Base
	Hotel       Hotel `gorm:"foreignkey:HotelID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"hotel"`
	User        User  `gorm:"foreignkey:UserID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"user"`
	CreatedUser User  `gorm:"foreignKey:CreatedBy;constraint:onUpdate:CASCADE;onDelete:CASCADE" json:"created_user"`
	UpdatedUser User  `gorm:"foreignKey:UpdatedBy;constraint:onUpdate:CASCADE;onDelete:CASCADE" json:"updated_user"`
}
