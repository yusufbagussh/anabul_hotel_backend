package entity

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
	"time"
)

// User represents users table in database
type User struct {
	ID                 string `gorm:"type:varchar(36);primaryKey;not null" json:"id"`
	Name               string `gorm:"type:varchar(100);not null" json:"name"`
	Email              string `gorm:"unique;not null;type:varchar(100)" json:"email"`
	Password           string `gorm:"->;<-;not null" json:"-"`
	HotelID            string `json:"hotel_id" gorm:"type:varchar(36);default:null"`
	Address            string `gorm:"default:null" json:"address"`
	Phone              uint64 `gorm:"default:null" json:"no_hp"`
	Image              string `gorm:"default:null;type:varchar(255)" json:"image"`
	Role               string `gorm:"default:'Customer'" sql:"type:ENUM('Super Admin', Admin','Staff','Customer')" json:"role"`
	VerificationCode   string
	Verified           bool `gorm:"not null"`
	PasswordResetToken string
	PasswordResetAt    time.Time
	Base
	Token string `gorm:"-" json:"token,omitempty"`
	Hotel Hotel  `gorm:"foreignkey:HotelID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"hotel"`
}

func (u *User) BeforeCreate(tx *gorm.DB) (err error) {
	u.ID = uuid.NewString()
	return
}
