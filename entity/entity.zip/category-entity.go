package entity

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
	"time"
)

type Category struct {
	IDCategory uuid.UUID `gorm:"primary_key" json:"id_category"`
	Name       string    `gorm:"type:varchar(100)" json:"name"`
	ClassID    uuid.UUID `gorm:"default:null" json:"-"`
	CreatedAt  time.Time
	UpdatedAt  time.Time
	DeletedAt  gorm.DeletedAt
	Class      Class `gorm:"foreignkey:ClassID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"class"`
}
