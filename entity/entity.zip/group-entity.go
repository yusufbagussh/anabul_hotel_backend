package entity

import "github.com/google/uuid"

type Group struct {
	IDCategory uint64    `gorm:"primary_key;autoIncrement" json:"id_category"`
	Name       string    `gorm:"type:varchar(100)" json:"name"`
	HotelID    uuid.UUID `gorm:"default:null" json:"hotel_id"`
	Base
	Hotel Hotel `gorm:"foreignkey:HotelID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"hotel"`
}
