package entity

type ServiceDetail struct {
	IDService uint64  `gorm:"primary_key;autoIncrement" json:"id_service_detail"`
	ServiceID uint64  `gorm:"not null" json:"-"`
	GroupID   uint64  `gorm:"not null" json:"-"`
	Price     float64 `gorm:"not null" json:"price"`
	Base
	Service Service `gorm:"foreignKey:ServiceID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"service"`
	Group   Group   `gorm:"foreignKey:GroupID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"group"`
}
