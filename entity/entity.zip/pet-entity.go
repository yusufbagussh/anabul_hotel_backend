package entity

import "github.com/google/uuid"

type Pet struct {
	IDPet     uint64    `gorm:"primary_key;autoIncrement" json:"id_pet"`
	Name      string    `gorm:"type:varchar(100)" json:"name"`
	UserID    uuid.UUID `gorm:"default:null" json:"-"`
	SpeciesID uint64    `gorm:"default:null" json:"-"`
	Base
	User    User    `gorm:"foreignkey:UserID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"user"`
	Species Species `gorm:"foreignkey:SpeciesID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"species"`
}
