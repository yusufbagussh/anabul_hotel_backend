package entity

import "github.com/google/uuid"

type Species struct {
	IDSpecies uint64    `gorm:"primary_key;autoIncrement" json:"id_species"`
	Name      string    `gorm:"type:varchar(100)" json:"name"`
	HotelID   uuid.UUID `gorm:"default:null" json:"hotel_id"`
	Base
	Hotel Hotel `gorm:"foreignkey:HotelID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"hotel"`
}
