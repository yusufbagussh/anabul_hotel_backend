package entity

import "github.com/google/uuid"

type CageType struct {
	IDCageCategory uint64    `gorm:"primary_key;autoIncrement" json:"id_cage_type"`
	Name           string    `gorm:"type:varchar(100);not null" json:"name"`
	Length         float32   `gorm:"not null" json:"length"`
	Width          float32   `gorm:"not null" json:"width"`
	Height         float32   `gorm:"not null" json:"height"`
	HotelID        uuid.UUID `gorm:"default:null" json:"hotel_id"`
	Base
	Hotel Hotel `gorm:"foreignkey:HotelID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"hotel"`
}
