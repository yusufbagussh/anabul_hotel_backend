package entity

type Rate struct {
	IDRate              uint64 `gorm:"primary_key;autoIncrement" json:"id_rate"`
	Star                uint8  `gorm:"type:varchar(100)" json:"start"`
	Comment             string `gorm:"default:null" json:"comment"`
	ReservationDetailID uint64 `gorm:"default:null" json:"-"`
	Base
	ReservationDetail ReservationDetail `gorm:"foreignkey:ReservationDetailID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"reservation_detail"`
}
