package entity

import "github.com/google/uuid"

type CageCategory struct {
	IDCageCategory uint64    `gorm:"primary_key;autoIncrement" json:"id_cage_category"`
	Name           string    `gorm:"type:varchar(100);not null" json:"name"`
	HotelID        uuid.UUID `gorm:"default:null" json:"hotel_id"`
	Base
	Hotel Hotel `gorm:"foreignkey:HotelID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"hotel"`
}
