package entity

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
	"time"
)

// Hotel represents users table in database
type Hotel struct {
	IDHotel     string  `gorm:"type:varchar(36);primaryKey;not null" json:"id_hotel"`
	Name        string  `gorm:"type:varchar(100);not null" json:"name"`
	Email       string  `gorm:"unique;not null;type:varchar(100)" json:"email"`
	ProvinceID  string  `json:"province_id" gorm:"type:varchar(36);not null"`
	CityID      string  `json:"city_id" gorm:"type:varchar(36);not null"`
	DistrictID  string  `json:"district_id" gorm:"type:varchar(36);not null"`
	Address     string  `gorm:"default:null" json:"address"`
	Phone       uint64  `gorm:"default:null" json:"no_hp"`
	Image       string  `gorm:"default:null;type:varchar(255)" json:"image"`
	Latitude    float64 `gorm:"default:null" json:"latitude"`
	Longitude   float64 `gorm:"default:null" json:"longitude"`
	Requirement string  `gorm:"default:null" json:"requirement"`
	Regulation  string  `gorm:"default:null" json:"regulation"`
	CreatedAt   time.Time
	UpdatedAt   time.Time
	DeletedAt   gorm.DeletedAt
	Province    Province `gorm:"foreignkey:ProvinceID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"province""`
	City        City     `gorm:"foreignkey:CityID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"province""`
	District    District `gorm:"foreignkey:DistrictID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"province""`
}

func (h *Hotel) BeforeCreate(tx *gorm.DB) (err error) {
	//if utils.EnvVar("APP_ENV", "DEVELOPMENT") != "DEVELOPMENT" {
	h.IDHotel = uuid.NewString()
	return
	//}
	//return
}
