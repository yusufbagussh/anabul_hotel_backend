package entity

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
	"time"
)

type Class struct {
	IDClass   uuid.UUID `gorm:"primary_key" json:"id_class"`
	Name      string    `gorm:"type:varchar(100)" json:"name"`
	CreatedAt time.Time
	UpdatedAt time.Time
	DeletedAt gorm.DeletedAt
}
