package entity

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
	"time"
)

type City struct {
	IDCity     string `gorm:"type:varchar(36);primaryKey;not null" json:"id_city"`
	Name       string `gorm:"type:varchar(100)" json:"name"`
	ProvinceID string `json:"province_id" gorm:"type:varchar(36);not null"`
	CreatedAt  time.Time
	UpdatedAt  time.Time
	DeletedAt  gorm.DeletedAt
	Province   Province `gorm:"foreignkey:ProvinceID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"province"`
}

func (c *City) BeforeCreate(tx *gorm.DB) (err error) {
	c.IDCity = uuid.NewString()
	return
}
