package entity

type CageCategoryType struct {
	IDCageCategoryType uint64  `gorm:"primary_key;autoIncrement" json:"id_cage_category_type"`
	CageCategoryID     uint64  `gorm:"not null" json:"cage_category_id"`
	CageTypeID         uint64  `gorm:"not null" json:"cage_type_id"`
	Price              float64 `gorm:"not null" json:"price"`
	Base
	CageCategory CageCategory `gorm:"foreignkey:CageCategoryID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"cage_category"`
	CageType     CageType     `gorm:"foreignkey:CageTypeID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"cage_type"`
}
