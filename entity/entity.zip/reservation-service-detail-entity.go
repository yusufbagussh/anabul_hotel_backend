package entity

type ReservationServiceDetail struct {
	IDReservationServiceDetail uint64 `gorm:"primary_key;autoIncrement" json:"id_reservation_service_detail"`
	ReservationDetailID        uint64 `gorm:"not null" json:"-"`
	ServiceDetailID            uint64 `gorm:"not null" json:"-"`
	Base
	ServiceDetail     ServiceDetail     `gorm:"foreignKey:ServiceDetailID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"service_detail"`
	ReservationDetail ReservationDetail `gorm:"foreignKey:ReservationDetailID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"service_detail"`
}
