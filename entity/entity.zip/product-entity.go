package entity

import "github.com/google/uuid"

type Product struct {
	IDProduct uint64    `gorm:"primary_key;autoIncrement" json:"id_product"`
	Name      string    `gorm:"type:varchar(100);not null" json:"name"`
	Price     float64   `gorm:"not null" json:"price"`
	HotelID   uuid.UUID `gorm:"default:null" json:"hotel_id"`
	Base
	Hotel Hotel `gorm:"foreignkey:HotelID;constraint:onUpdate:CASCADE,onDelete:CASCADE" json:"hotel"`
}
